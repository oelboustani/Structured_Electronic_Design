

=======
Circuit
=======




I built the circuit in LTSpice and performed the simulations there to get a coherent picture over all requirements (distortion is inherently non-linear which cannot be simulated in SLiCAP. 


----------------
Circuit diagramm
----------------




.. figure:: /img/Circuit.png
    :width: 1024




The circuit contains both source capacitance and load resistance as well as a proper biasing circuitry. 
