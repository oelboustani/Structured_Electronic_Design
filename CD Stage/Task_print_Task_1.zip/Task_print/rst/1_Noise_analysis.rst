

================
1 Noise analysis
================




First we observe the noise performance of the circuit. To this end we choose the length of the antenna as long as possible which aids in enlargening the source capacitance and lowers the requirement for the voltage to voltage gain of the amplifier. 


:math:`l=0.5 m 


We can deduce from the noise spectrum that there is an optimum for the noise when :math:`C_iss=C_s`  


This leads to an optimum for the area of the transistor that is solely dependant on this parameter and technology parameters. 


W*L=7.8*10^-10 m^2:math:` 
